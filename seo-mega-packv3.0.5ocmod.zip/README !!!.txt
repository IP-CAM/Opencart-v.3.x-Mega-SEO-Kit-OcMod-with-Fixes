Go to the documentation and read the installation instructions.

You should open the file index.html in documentation folder using a browser or go to: 
http://ocdemo.com/seo_mega_pack/docs-2/