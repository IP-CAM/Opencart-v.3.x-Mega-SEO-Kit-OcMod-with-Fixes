<?php

/**
 * SEO Mega Pack
 * 
 * @author info@ocdemo.eu <info@ocdemo.eu>
 */

abstract class SeoMegaPack_AbstractManager {
	
	/**
	 * @var ControllerModuleSeoMegaPack
	 */
	protected $_controller					= NULL;
	
	/**
	 * @var int
	 */
	protected $_sort						= 100;
	
	/**
	 * @var bool
	 */
	protected $_hasColumnName				= true;
	
	/**
	 * @var bool
	 */
	protected $_hasColumnUrl				= true;
	
	/**
	 * @var bool
	 */
	protected $_hasColumnTitle				= true;
	
	/**
	 * @var bool
	 */
	protected $_hasColumnHeadingTitle		= true;
	
	/**
	 * @var bool
	 */
	protected $_hasColumnMetaKeywords		= false;
	
	/**
	 * @var bool
	 */
	protected $_hasColumnMetaDescription	= false;
	
	/**
	 * @var bool 
	 */
	protected $_isMultilanguage				= true;
	
	/**
	 * @var bool
	 */
	protected $_hasColumnTags				= false;
	
	protected $_installed					= true;
	
	protected $_version						= '2';
	
	protected $_queryCount					= false;
	
	////////////////////////////////////////////////////////////////////////////
	
	/**
	 * @param ControllerModuleSeoMegaPack $controller
	 */
	public function __construct( ControllerExtensionModuleSeoMegaPack $controller ) {
		$this->_controller = $controller;
	}
	
	public function queryCount( $count = NULL ) {
		$this->_queryCount = (bool) $count;
		
		return $this;
	}
	
	/**
	 * @return int
	 */
	public function sort() {
		return $this->_sort;
	}	
	
	public function version() {
		return $this->_version;
	}
	
	/**
	 * @return bool
	 */
	public function installed() {
		return $this->_installed;
	}
	
	protected function _updateUrlAlias( $type, $id, $language_id, $store_id, $keyword ) {
	
		$this->_controller->db->query("DELETE FROM " . DB_PREFIX . "seo_url WHERE query='" . $type . "_id=" . $id . "' AND language_id=" . $language_id . " AND store_id=" . $store_id );

		
		if( ! empty( $keyword ) ) {
			$this->_controller->db->query("
				INSERT INTO
					" . DB_PREFIX . "seo_url
				SET
					keyword='" . $this->_controller->db->escape( $this->_controller->_createUniqueKeyword( $store_id, $keyword, NULL, $type . '_id=' . $id ) ) . "',
					query='" . $type . "_id=" . $id . "',
					language_id=" . $language_id . ",
					store_id=" . $store_id . "
			");
		}
	}
	
	public function addUrlAlias( $data, & $items ) {
		return $items;
	}
	
	// Has /////////////////////////////////////////////////////////////////////
	
	public function isMultilanguage() {
		return $this->_isMultilanguage;
	}
	
	public function hasColumnName() {
		return $this->_hasColumnName;
	}
	
	public function hasColumnUrl() {
		return $this->_hasColumnUrl;
	}
	
	public function hasColumnTitle() {
		return $this->_hasColumnTitle;
	}
	
	public function hasColumnHeadingTitle() {
		return $this->_hasColumnHeadingTitle;
	}
	
	public function hasColumnMetaKeywords() {
		return $this->_hasColumnMetaKeywords;
	}
	
	public function hasColumnMetaDescription() {
		return $this->_hasColumnMetaDescription;
	}
	
	public function hasColumnTags() {
		return $this->_hasColumnTags;
	}
	
	// Abstract ////////////////////////////////////////////////////////////////
	
	/**
	 * @param array $data
	 * @param array $session
	 * @param bool $count
	 * @return string
	 */
	abstract public function getQuery( $data, $session );
	
	/**
	 * @return string
	 */
	abstract public function getTabLabel();
	
	/**
	 * @param array $post
	 * @param int $id
	 * @param int $language_id
	 * @param int $store_id
	 * @return void
	 */
	abstract public function save( $post, $id, $language_id, $store_id );
}